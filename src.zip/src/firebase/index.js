import * as firebase from './firebase';
const auth = firebase.auth;

export {
  auth,
  firebase,
};
